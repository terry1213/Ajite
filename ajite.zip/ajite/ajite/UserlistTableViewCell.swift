//
//  UserlistTableViewCell.swift
//  ajite
//
//  Created by Chanwoong Ahn on 2020/08/05.
//  Copyright © 2020 ajite. All rights reserved.
//

import UIKit

class UserlistTableViewCell: UITableViewCell {
    @IBOutlet var nameBox: UILabel!
    
    @IBOutlet var checkBox: UIButton!
    

}
